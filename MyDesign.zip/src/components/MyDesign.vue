<template>
  <div class="hello">
    <header>
      <ul>
        <li><a href="#">Code</a></li>
        <li><a href="#">About</a></li>
      </ul>
    </header>
    <section class="hero">
      <h2>3 Pages in 3 weeks</h2>
      <p>we learn various of tools which are effictive,powerful,agile to build Web pages from scracth,and learn by practicing. After 3 weeks,attenders should be able to implement most of the Web design in <span>HTML5/CSS3</span> easily.</p>
    </section>
    <section class="topics container">
      <h3>What do we learn?</h3>
      <ul>
        <li>
          <div class="subject">
            <i class='icon-wrench'></i>
            <h4>Tools</h4>
            <p>We introduce tools like Sublime,Emmet,LiveReload, Guard to speed up the whole process</p>
          </div>
        </li>
        <li>
          <div class="subject">
            <i class="icon-books"></i>
            <h4>Design theory</h4>
            <p>Some basic theory of design,color scheme,hierachy,imagery.</p>
          </div>
        </li>
        <li>
          <div class="subject">
            <i class="icon-spinner8"></i>
            <h4>Workflow</h4>
            <p>A much more modern way of development,design,or both.we intend to make the whole workflow efficiens.</p>
          </div>
        </li>
      </ul>
    </section>
    <section class="sample" id="week-1">

      <h3>SAMPLES TO BE IMPLEMENTED</h3>
      <div class="subsample">
        <ul>
          <li>
            <div class="thumb">
              <img src="../assets/img/2.jpg" alt="">
            </div>
          </li>
          <li>
            <div class="description">
              <h4>Week 1:Find an agent</h4>
              <p>In the first week,we will learn how to setup the most modern and effective environment first. We use Submlime+Emmet plugin for HTML/CSS code composing.and Compass+SCSS for css,then Guard+LiveReload for quick feedback and enhancement</p>
              <p>During the workshop,people learn how to implement the mockup from scrath,how to structure the HTML documents.etc</p>
              <p>also we highly recommerded people work in pairs,then they can learn from each other,and get comfortable when blocked by some details</p>
            </div>
          </li>
        </ul>
      </div> 
      <div class="subsample">
        <ul>  
          <li>
            <div class="description">
              <h4>Week 1:Find an agent</h4>
              <p>In the first week,we will learn how to setup the most modern and effective environment first. We use Submlime+Emmet plugin for HTML/CSS code composing.and Compass+SCSS for css,then Guard+LiveReload for quick feedback and enhancement</p>
              <p>During the workshop,people learn how to implement the mockup from scrath,how to structure the HTML documents.etc</p>
              <p>also we highly recommerded people work in pairs,then they can learn from each other,and get comfortable when blocked by some details</p>
            </div>
          </li>
          <li>
            <div class="thumb">
              <img src="../assets/img/2.jpg" alt="">
            </div>
          </li>
        </ul>
      </div>
      <div class="subsample">
        <ul>
         <li>
            <div class="thumb">
              <img src="../assets/img/2.jpg" alt="">
            </div>
          </li>  
          <li>
            <div class="description">
              <h4>Week 1:Find an agent</h4>
              <p>In the first week,we will learn how to setup the most modern and effective environment first. We use Submlime+Emmet plugin for HTML/CSS code composing.and Compass+SCSS for css,then Guard+LiveReload for quick feedback and enhancement</p>
              <p>During the workshop,people learn how to implement the mockup from scrath,how to structure the HTML documents.etc</p>
              <p>also we highly recommerded people work in pairs,then they can learn from each other,and get comfortable when blocked by some details</p>
            </div>
          </li>
         
        </ul>
      </div>
      <p class="bottom">Lorem ipsum dolor sit amet, consectetur <span>adipisicing</span> elit. Delectus optio <span>quo esse</span>, vitae aperiam dolore deserunt molestias magnam distinctio eveniet. Voluptate quas, magni quos laudantium unde doloribus illo provident optio!</p>
    </section>
    <section class="picwall">
      <h3>HOW DO WE LEARN</h3>
      <ul>
        <li>
          <div class="pic"><img src="../assets/img/2-1.jpg" alt=""></div>
        </li>
        <li>
          <div class="pic"><img src="../assets/img/2-1.jpg" alt=""></div>
        </li>
        <li>
          <div class="pic"><img src="../assets/img/2-1.jpg" alt=""></div>
        </li>
        <li>
          <div class="pic"><img src="../assets/img/2-1.jpg" alt=""></div>
        </li>
        <li>
          <div class="pic"><img src="../assets/img/2-1.jpg" alt=""></div>
        </li>
        <li>
          <div class="pic"><img src="../assets/img/2-1.jpg" alt=""></div>
        </li>
        <li>
          <div class="pic"><img src="../assets/img/2-1.jpg" alt=""></div>
        </li>
        <li>
          <div class="pic"><img src="../assets/img/2.8.jpg" alt=""></div>
        </li>
      </ul>
    </section>
    <section class="show">
      <h3>PAGE GALLERY</h3>
      <ul>
        <li>
          <a href="#" target="_blank" class="mask"></a>
          <img src="../assets/img/5.jpg" alt="" class="case">
          <article class="information">
            <section class="detail">
              <img src="../assets/img/4.jpg" class="avator">
              <div class="contact">
                <span class="name">Li Liuchao</span>
                <span class="role">Dev</span>
                <time class="date">2018-07-01</time>
                <p>My Portfolio</p>
              </div>
              <a href="#" class="like">
                <div class="icon-svg"></div></a>
            </section>
          </article>
        </li>
        <li>
          <a href="#" target="_blank" class="mask"></a>
          <img src="../assets/img/5.jpg" alt="" class="case">
          <article class="information">
            <section class="detail">
              <img src="../assets/img/4.jpg" class="avator">
              <div class="contact">
                <span class="name">Li Liuchao</span>
                <span class="role">Dev</span>
                <time class="date">2018-07-01</time>
                <p>My Portfolio</p>
              </div>
              <a href="#" class="like">
                <div class="icon-svg"></div></a>
            </section>
          </article>
        </li>
        <li>
          <a href="#" target="_blank" class="mask"></a>
          <img src="../assets/img/5.jpg" alt="" class="case">
          <article class="information">
            <section class="detail">
              <img src="../assets/img/4.jpg" class="avator">
              <div class="contact">
                <span class="name">Li Liuchao</span>
                <span class="role">Dev</span>
                <time class="date">2018-07-01</time>
                <p>My Portfolio</p>
              </div>
              <a href="#" class="like">
                <div class="icon-svg"></div></a>
            </section>
          </article>
        </li>
        <li>
          <a href="#" target="_blank" class="mask"></a>
          <img src="../assets/img/5.jpg" alt="" class="case">
          <article class="information">
            <section class="detail">
              <img src="../assets/img/4.jpg" class="avator">
              <div class="contact">
                <span class="name">Li Liuchao</span>
                <span class="role">Dev</span>
                <time class="date">2018-07-01</time>
                <p>My Portfolio</p>
              </div>
              <a href="#" class="like">
                <div class="icon-svg"></div></a>
            </section>
          </article>
        </li>
        <li>
          <a href="#" target="_blank" class="mask"></a>
          <img src="../assets/img/5.jpg" alt="" class="case">
          <article class="information">
            <section class="detail">
              <img src="../assets/img/4.jpg" class="avator">
              <div class="contact">
                <span class="name">Li Liuchao</span>
                <span class="role">Dev</span>
                <time class="date">2018-07-01</time>
                <p>My Portfolio</p>
              </div>
              <a href="#" class="like">
                <div class="icon-svg"></div></a>
            </section>
          </article>
        </li>
        <li>
          <a href="#" target="_blank" class="mask"></a>
          <img src="../assets/img/5.jpg" alt="" class="case">
          <article class="information">
            <section class="detail">
              <img src="../assets/img/4.jpg" class="avator">
              <div class="contact">
                <span class="name">Li Liuchao</span>
                <span class="role">Dev</span>
                <time class="date">2018-07-01</time>
                <p>My Portfolio</p>
              </div>
              <a href="#" class="like">
                <div class="icon-svg"></div></a>
            </section>
          </article>
        </li>
        <li>
          <a href="#" target="_blank" class="mask"></a>
          <img src="../assets/img/5.jpg" alt="" class="case">
          <article class="information">
            <section class="detail">
              <img src="../assets/img/4.jpg" class="avator">
              <div class="contact">
                <span class="name">Li Liuchao</span>
                <span class="role">Dev</span>
                <time class="date">2018-07-01</time>
                <p>My Portfolio</p>
              </div>
              <a href="#" class="like">
                <div class="icon-svg"></div></a>
            </section>
          </article>
        </li>
        <li>
          <a href="#" target="_blank" class="mask"></a>
          <img src="../assets/img/5.jpg" alt="" class="case">
          <article class="information">
            <section class="detail">
              <img src="../assets/img/4.jpg" class="avator">
              <div class="contact">
                <span class="name">Li Liuchao</span>
                <span class="role">Dev</span>
                <time class="date">2018-07-01</time>
                <p>My Portfolio</p>
              </div>
              <a href="#" class="like">
                <div class="icon-svg"></div></a>
            </section>
          </article>
        </li>
        <li>
          <a href="#" target="_blank" class="mask"></a>
          <img src="../assets/img/5.jpg" alt="" class="case">
          <article class="information">
            <section class="detail">
              <img src="../assets/img/4.jpg" class="avator">
              <div class="contact">
                <span class="name">Li Liuchao</span>
                <span class="role">Dev</span>
                <time class="date">2018-07-01</time>
                <p>My Portfolio</p>
              </div>
              <a href="#" class="like">
                <div class="icon-svg"></div></a>
            </section>
          </article>
        </li>
        <li>
          <a href="#" target="_blank" class="mask"></a>
          <img src="../assets/img/5.jpg" alt="" class="case">
          <article class="information">
            <section class="detail">
              <img src="../assets/img/4.jpg" class="avator">
              <div class="contact">
                <span class="name">Li Liuchao</span>
                <span class="role">Dev</span>
                <time class="date">2018-07-01</time>
                <p>My Portfolio</p>
              </div>
              <a href="#" class="like">
                <div class="icon-svg"></div></a>
            </section>
          </article>
        </li>
        <li>
          <a href="#" target="_blank" class="mask"></a>
          <img src="../assets/img/5.jpg" alt="" class="case">
          <article class="information">
            <section class="detail">
              <img src="../assets/img/4.jpg" class="avator">
              <div class="contact">
                <span class="name">Li Liuchao</span>
                <span class="role">Dev</span>
                <time class="date">2018-07-01</time>
                <p>My Portfolio</p>
              </div>
              <a href="#" class="like">
                <div class="icon-svg"></div></a>
            </section>
          </article>
        </li>
        <li>
          <a href="#" target="_blank" class="mask"></a>
          <img src="../assets/img/5.jpg" alt="" class="case">
          <article class="information">
            <section class="detail">
              <img src="../assets/img/4.jpg" class="avator">
              <div class="contact">
                <span class="name">Li Liuchao</span>
                <span class="role">Dev</span>
                <time class="date">2018-07-01</time>
                <p>My Portfolio</p>
              </div>
              <a href="#" class="like">
                <div class="icon-svg"></div></a>
            </section>
          </article>
        </li>
      </ul> 
    </section>
    <footer>
      <p>Created by  <span>&nbsp;Liuchao Li</span></p>
    </footer>

  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
$background-color:#eeeeee;
$text-color:#3e3e3e;
$light-text-color:#eeeeee;
$header-color:hsl(160,90%,40%);
$mask-color:#333333;


@mixin clearfix(){
  clear:both;
}

@mixin section-title(){
  font-size:2em;
  text-transform:uppercase;
  color:$header-color;
  padding:1em 0 1em 0em;
  &:after{
    content:'';
    display:block;
    background-color:#cccccc;
    width:2em;
    height:.2em;
    margin: .4em auto;
  }
}


@mixin border-radius($border){
  border-radius:$border;
}
.hello{
  font-size:62.5%;
  font-family:'Open Sans',sans-serif;
  text-align:center;
  color:$text-color;
  background-color:white;
  width:100%;
  margin:0 auto;

  header{
    padding:0 1em;
    height:5em;
    background-color:$header-color;
    ul{
      list-style-type: none;
      margin-top:0;
      
      li{
        float:left;
        height:5em;

        a{
          font-size:1.9em;
          text-decoration:none;
          color:white;
          display:inline-block;
          padding:1.0em 1em;
        }
        a:hover{
          background-color:hsl(160,90%,35%);
        }
      }
      @include clearfix;
    }
  }
  .hero{
    width:100%;
    min-height:50em;
    position:relative;
    background-color:$mask-color;
    z-index:1;
    &:after{
      background:url(../assets/img/1.jpg);
      background-size:cover;
      position:absolute;
      content:"";
      z-index:-1;
      opacity:.2;
      width:100%;
      height:100%;
      top:0;
      left:0;
    }

    h2{
      font-size:6em;
      font-weight:bold;
      padding:3em 0 1em 0;
      text-transform:uppercase;
      color:white;
      margin-top :0;
    }

    p{
      max-width:70%;
      font-size:1.6em;
      font-weight:lighter;
      color:#cecece;
      light-height:1.4;
      margin:0 auto;
      padding:1em 0 8em 0;
      span{
        color:$header-color;
      }
    }
  }

  .topics{
    padding:1em 0 4em 0;
    background-color:#eeeeee;
    height:20em;
    width:100%;
    margin:0 auto;
    h3{
      @include section-title
    }
    ul{
      list-style-type: none;
      width:80%;
     margin: 0 auto;
      li{
        float:left;
        width:33.3%;
        i{
          font-size:3em;
        }
        h4{
          font-size:1.5em;
          padding:1em 0;
          font-weight:bold;
          margin:0em;
        }
        p{
          line-height:1.4;
          margin-top:0em;
          color:#6e6e6e;
          padding:0 3em;
          margin-bottom:4em;
        }
      }

    }
    @include clearfix;
  }
  .sample{
    width:100%;
    padding:1em 0 4em 0;
    margin:0em auto;
    
    height:101em;
    background-color:#dddddd;
    h3{
      @include section-title
    }
    .subsample{
      height:30em;
      ul{
        width:80%;
        margin:0 auto;
        list-style-type: none;
        li{
          
          float:left;
          width:50%;
          .thumb{
            width:100%;
            height:25em;
            overflow:hidden;
            margin: auto;

            img{
              width:90%;
              margin:0 auto;
            }
          }
          .description{
            h4{
              text-align:left;
              padding-left:1.5em;
              font-size:2em;
              font-weight:bold;
              margin:0 auto;
            }
            p{
              font-size:1.5em;
              width:90%;
              font-weight:lighter;
              line-height:1.4;
              color:#6e6e6e;
              text-align:left;
              padding:.5em 2em;
            }
          }

        } 
        @include clearfix;
      }
      
    }
    .bottom{
      margin:auto;
      // margin-top:25em;
      width:70%;

      padding: 0 4em 0 4em;
      font-size:1.4em;
      span{
        color:#8cd3b8;
      }

    }
  }

  .picwall{
    width:100%;
    height:50em;
    padding:2em 0 4em 0;
    background-color:#eeeeee;
    
    
    h3{
      @include section-title
    }
    ul{
      width:80%;
      margin:0 auto;
      list-style-type: none;
      li{
        width:25%;
        float:left;
        img{
          width:100%;
          height:100%;
        }
      }
    }


  }

  .show{
    width:100%;
    padding:2em 0 4em 0;
    margin:0em auto;

    height:98em;
    background-color:#dddddd;
    h3{
      @include section-title
    }

    a{
      text-decoration:none;
    }

    ul{
      width:80%;
      margin:0 auto;
      list-style-type: none;
      padding-left:0;
      li{
        float:left;
        width:33.33%;
        box-sizing:border-box;
        position: relative;
        height:22em;
        overflow:hidden;
        .case{
          width:100%;
          height:100%;
        }
        &:hover{
          .information{
            top:13em;
          }
        }
        .mask{
          display:block;
          position:absolute;
          top:-22em;
          left:0;
          height:100%;
          width:100%;
          background-color:$text-color;
          opacity:.1;
        }
      
        .information{
          position:absolute;
          background-color:$text-color;
          top:22em;
          left:0;
          width:100%;
          height:40%;
          opacity:.9;
          transition:all .4s ease-in-out;
          text-align:left;
          padding:0 1em;
          box-sizing:border-box;
          color:white;
          h3{
            font-size:2em;
            padding:1em 0;
          }
          .detail{
            position:relative;
            padding-top:2em;
            .avator{
              position: absolute;
              width:3em;
              bottom:0;
              height:3em;
              @include border-radius(100%);
            }
            p{
              padding:.5em 0 0 0;
              font-size:1.5em;
            }
            .contact{
              margin-left:4em;
              .name{
                font-weight:bold;
                margin-right:.5em;
              }
              .role{
                color:$light-text-color;
              }
            }
            .like{
              position:absolute;
              font-size:2em;
              bottom:0;
              right:0;
              color:white;
              background-color:$header-color;
              border:1px solid $header-color;
              padding:.2em;
              @include border-radius(100%);
              transition:all .3s ease-in-out;
              &:hover {
                color:$header-color;
                background-color:white;
                border:1px solid transparent;
              }
            }

          }
        }
      }
  }
    
  }


  footer{
    background-color:#333;
    padding:1.5em;
    p{
      margin:0;
      font-size:2em;
      color:#D9D9D9;
      span{
        color:$header-color;
      }
    }
  }
}


</style>
